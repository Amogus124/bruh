
Espa�ol/Spanish

Pon este script en la carpeta data de tu canci�n  

algo asi: assets/data/(la carpeta de tu canci�n preferida) 

o

Mods/data/(la carpeta de tu canci�n preferida)




English/Ingles

Put this script in the chart data folder of your favorite song, and voila! 

like this: assets/data/(your song)

or

mods/data/(your song)




