This is still in the experimental stage, 
the code is very different from the usual one in the script, 
you must put the code according to the stage, or else it won't work! 

I left an example so you can see how to use it, 
you could also use it as a template for your stages, 

I also left the script so you can experiment with new alternatives.

Put staysafe.json and staysafe.lua in Mods/stages 

and the staysafe folder in mods/images, 
just in case you want to try the stage yourself
