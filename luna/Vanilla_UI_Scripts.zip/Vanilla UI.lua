function onCreatePost()
	setProperty('scoreTxt.visible', false)
	setProperty('timeBar.visible', false)
	setProperty('timeBarBG.visible', false)
	setProperty('timeTxt.visible', false)
end

function onCreate()
	makeLuaText('oldScore', 'Score:' .. score, 800, 390, 670)
	setTextSize('oldScore', 15)
	setTextBorder('oldScore', 1.5, '000000')
	addLuaText('oldScore')
	if getPropertyFromClass('ClientPrefs', 'downScroll') == false then
	setProperty('oldScore.y', 670)
	elseif getPropertyFromClass('ClientPrefs', 'downScroll') == true then
	setProperty('oldScore.y', 106)
	end
end

function onRecalculateRating()
	setTextString('oldScore', 'Score:' .. score)
end