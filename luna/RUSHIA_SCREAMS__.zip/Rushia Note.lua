function onCreate()
	--Iterate over all notes
	for i = 0, getProperty('unspawnNotes.length')-1 do
		--Check if the note is a rushia from hololive
		if getPropertyFromGroup('unspawnNotes', i, 'noteType') == 'Rushia Note' then
			setPropertyFromGroup('unspawnNotes', i, 'texture', 'NOTE_rushia');

			if getPropertyFromGroup('unspawnNotes', i, 'mustPress') then
			end
		end
	end
end

local screamAnims = {"singLEFT-alt", "singDOWN-alt", "singUP-alt", "singRIGHT-alt"}
function opponentNoteHit(id, direction, noteType, isSustainNote)
	if noteType == 'Rushia Note' then
	if getProperty('health') > 0.1 then
	setProperty('health',getProperty('health')-0.03)
		characterPlayAnim('dad', screamAnims[direction + 1], false);
      end
   end
end